<?php

namespace SOM\FastTravel\command;

use SOM\FastTravel\Main;
use pocketmine\player\Player;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use SOM\FastTravel\form\WarpForm;

class WarpCommand extends Command
{

    public function __construct()
    {
        parent::__construct("Fasttravel", "§eWarpUI For Better Experience");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): mixed
    {
        if ($sender instanceof Player) {
            $sender->sendForm(new WarpForm(Main::getInstance()));
            return true;
        }
        $sender->sendMessage("Use this command in-game");
        return false;
    }
}
