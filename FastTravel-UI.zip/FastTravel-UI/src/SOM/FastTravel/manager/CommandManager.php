<?php

namespace SOM\FastTravel\managers;

use pocketmine\Server;
use SOM\FastTravel\command\WarpCommand;

final class CommandManager
{
    public static function initalize(): void
    {
        foreach (self::getCommands() as $key => $value) {
            Server::getInstance()->getCommandMap()->register($key, $value);
        }
    }

    public static function getCommands(): array
    {
        return [
            "Fasttravel" => new WarpCommand()
        ];
    }
}
