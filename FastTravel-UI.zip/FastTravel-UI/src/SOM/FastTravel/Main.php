<?php
    

namespace SOM\FastTravel;

use pocketmine\Server;
use pocketmine\player\Player;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;
use Pushkar\MagicCore\managers\CommandManager;

class Main extends PluginBase 
{
    public function onEnable() : void {
        $this->getLogger()->info("FastTravel UI by som is enabled 🔥");
        }
    public function ondisable(): void {
        $this->getLogger()->info("FastTravel ui by som is disable 😴");
        }
    }
    